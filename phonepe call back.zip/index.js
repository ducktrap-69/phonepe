const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const ejs = require("ejs");
const axios = require("axios");
const crypto = require("crypto");

const app = express();
app.use(cors());

// EJS module
app.set("view engine", "ejs");
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(__dirname + "/public"));

let paymentDetails = {};

app.get("/", (req, res) => {
  res.render("text");
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

// fetching entered data and updating on the database for end parking then calculating amount
app.post("/payment", async (req, res) => {
  // Extract necessary data from the request body.
  const totalCost = req.body.totalCost;

  // texting
  // console.log("totalCost:", totalCost);

  function generateUserId() {
    const timestamp = Date.now();
    const random = Math.floor(Math.random() * 1000);
    return `order_${timestamp}_${random}`;
  }

  function generateTransactionId() {
    const timestamp = Date.now();
    const random = Math.floor(Math.random() * 1000);
    return `txn_${timestamp}_${random}`;
  }
  // Extract necessary data from the request body.
  const merchantId = "PGTESTPAYUAT";
  const merchantTransactionId = generateTransactionId();
  const merchantUserId = generateUserId();
  // const amount = totalCost * 100;
  const amount = totalCost * 100;
  const redirectUrl = "http://localhost:3000/confirmation";
  const redirectMode = "REDIRECT";
  const callbackUrl = "http://localhost:3000/";

  // Construct the payload object
  const payload = {
    merchantId,
    merchantTransactionId,
    merchantUserId,
    amount,
    redirectUrl,
    redirectMode,
    callbackUrl,
    paymentInstrument: {
      type: "PAY_PAGE",
    },
  };

  // Calculate X-VERIFY header
  async function calculateXVerify(payload) {
    const saltKey = "099eb0cd-02cf-4e2a-8aca-3e6c6aff0399";
    const saltIndex = 1;
    const inputString = base64Encode(payload) + "/pg/v1/pay" + saltKey;

    const hash = await sha256Hash(inputString);
    // texting
    // console.log(hash);
    const xkey = hash + "###" + saltIndex;
    return xkey;
  }

  // base 64 playload
  function base64Encode(input) {
    const encoder = new TextEncoder();
    const data = encoder.encode(input);
    const base64 = btoa(String.fromCharCode(...data));
    return base64;
  }

  // Function to calculate SHA-256 hash
  async function sha256Hash(payload) {
    const encoder = new TextEncoder();
    const data = encoder.encode(payload);

    const hashBuffer = await crypto.subtle.digest("SHA-256", data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashHex = hashArray
      .map((byte) => byte.toString(16).padStart(2, "0"))
      .join("");
    return hashHex;
  }

  // Calculate X-VERIFY header
  const xVerify = await calculateXVerify(JSON.stringify(payload));
  // texting
  console.log(xVerify);

  // Set up the HTTP request using Axios
  const options = {
    method: "POST",
    url: "https://api-preprod.phonepe.com/apis/pg-sandbox/pg/v1/pay",
    headers: {
      "Content-Type": "application/json",
      "X-VERIFY": xVerify,
    },
    data: {
      request: Buffer.from(JSON.stringify(payload)).toString("base64"),
      headers: {
        accept: "application/json",
        "Content-Type": "application/json",
      },
    },
  };
  try {
    const response = await axios.request(options);
    const fetchedData = response.data;
    paymentDetails = {
      merchantId,
      merchantTransactionId,
      paymentUrl: fetchedData.data.instrumentResponse.redirectInfo.url,
    };
    console.log(response.data);
    res.redirect(paymentDetails.paymentUrl);
  } catch (error) {
    console.error("Payment initiation failed. Error:", error.message);
    res.status(500).send(`Payment initiation failed. Error: ${error.message}`);
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

app.get("/confirmation", async (req, res) => {
  // text method - failure
  // const capturedData = req.body;
  // res.send(capturedData);

  if (!paymentDetails) {
    return res.status(404).send("No payment details found");
  }

  const { merchantId, merchantTransactionId } = paymentDetails;
  console.log("merchantTransactionId =", merchantTransactionId);
  console.log("merchantId =", merchantId);

  async function calculateXVerify(merchantId, merchantTransactionId) {
    const saltKey = "099eb0cd-02cf-4e2a-8aca-3e6c6aff0399";
    const saltIndex = 1;

    const inputString = `${saltKey}/v3/transaction/${merchantId}/${merchantTransactionId}/status`;
    console.log("inputString", inputString);

    const hash = await sha256Hash(inputString);
    console.log("sha256", hash);

    const xkey = hash + "###" + saltIndex;
    console.log("xverify", xkey);
    return xkey;
  }
  async function sha256Hash(payload) {
    const encoder = new TextEncoder();
    const data = encoder.encode(payload);

    const hashBuffer = await crypto.subtle.digest("SHA-256", data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashHex = hashArray
      .map((byte) => byte.toString(16).padStart(2, "0"))
      .join("");
    return hashHex;
  }
  const options = {
    method: "GET",
    url: `https://mercury-uat.phonepe.com/v3/transaction/${merchantId}/${merchantTransactionId}/status`,
    headers: {
      accept: "application/json",
      "Content-Type": "application/json",
      "X-VERIFY": await calculateXVerify(merchantId, merchantTransactionId),
    },
  };

  try {
    const response = await axios.request(options);
    console.log(response.data);
    res.send(response.data);
  } catch (error) {
    console.error(error);
    res.status(500).send("Confirmation request failed.");
  }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log("Server is active and running.");
});
